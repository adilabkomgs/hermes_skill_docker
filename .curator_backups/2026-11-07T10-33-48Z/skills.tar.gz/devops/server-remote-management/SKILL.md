---
name: server-remote-management
description: Skills for managing and querying remote servers via SSH and other protocols
category: devops
created: 2026-10-31
updated: 2026-10-31
---

# Server Remote Management

## Overview
Skills for managing and querying remote servers via various protocols (SSH, remote CLI). Handles infrastructure verification, backup checks, and cross-machine operations.

## Trigger Conditions
- User mentions "cek mesin", "cek di server", "remote", "SSH ke", atau nama VPS
- User requests file/folder checks on remote systems
- Connection to external machines is needed

## Language Preference
**DEFAULT LANGUAGE: Indonesia** when user indicates preference with "gunakan bahasa indonesia" or similar. Switch to English only if user explicitly requests or switches mid-conversation.

## Core Workflow

### 1. Verify Access Method
- Check if user provides SSH credentials (hostname, username, IP)
- If no credentials given, ask for explicit permission before attempting any remote lookup
- Never read connected accounts silently - ask each time

### 2. Connection Process
1. Confirm connection details with user
2. State what you intend to look up and get consent
3. Provide manual SSH command for user reference
4. Wait for user to execute and report results

### 3. Remote File/Directory Checks
When checking paths like docker backups:
```bash
# Manual command user can run
ssh user@ip 'ls -la /path/to/check'

# Or for backup verification
ssh user@ip 'ls -la /path/to/docker-backups'
```

## Common Pitfalls
- **Path confusion**: User may specify wrong path structure. Always verify existence first with `ls -la` before deeper inspection.
- **Assumption of local access**: VPS checks often require user's manual SSH. Don't wait for automated response that won't happen.
- **LAMPP path variations**: Standard path is `/opt/lampp/htdocs/` but some installs use different locations. Verify with `find / -name "docker-backups" -type d 2>/dev/null` if initial path fails.
### SSH key setup sequence
- When connection fails with "No identities found", run: `ssh-keygen -t ed25519 -f /root/.ssh/id_ed25519 -C "description"` then `ssh-copy-id -i /root/.ssh/id_ed25519.pub user@host`
- **Key generation parameters**: Use `-t ed25519` (fast, secure), `-C "purpose"` for identification
- Always verify key exists after generation: `ls -la /root/.ssh/id_ed25519*`

### Non-interactive Script Execution
- For menu-driven scripts (like dockertools.sh), use: `TERM=xterm bash -c "echo 'N' | bash script.sh"`
- Replace N with menu option number
- Always set `TERM=xterm` to avoid "TERM environment variable not set" error
- **Pattern: `docker ps --filter 'name=<container>' --format 'table {{.ID}}\t{{.Names}}\t{{.Status}}...'`** for container-specific queries
- **Direct docker stats**: `docker stats <container> --no-stream` for resource usage

### Docker Container Status Checking
When user says "cek mesin container X":
```bash
docker ps --filter 'name=<name>' --format 'table {{.ID}}\t{{.Names}}\t{{.Image}}\t{{.Status}}\t{{.Ports}}\t{{.Command}}'
```
- Filter by name to avoid noise
- Format output as table for readability
- Status shows uptime, port mappings

### SSH Key Setup Troubleshooting
- When connection fails with "No identities found", run: `ssh-keygen -t ed25519 -f /root/.ssh/id_ed25519 -C "purpose"` then `ssh-copy-id -i /root/.ssh/id_ed25519.pub user@host`
- After key generation, verify: `ls -la ~/.ssh/id_ed25519*`
- **Warning**: `ssh-copy-id` may report "All keys were skipped because they already exist" if key is already installed; this is not an error.

### Git Push Auth from Inside a Container
- If `git push` from inside a container fails with SSH auth, prefer switching to HTTPS + PAT rather than trying to inject host keys or private keys interactively.
- The terminal environment may block commands that include PATs inline for security.
- Recommended sequence:
  1. Set remote to HTTPS GitHub URL.
  2. Configure `git config --global credential.helper store`.
  3. Perform one authenticated push so GitHub credentials are saved.
  4. Subsequent pushes use the stored credential.
- If the user already has a PAT, have them complete the authenticated push themselves to avoid exposing the token in tooling.
- **Verified working case (Nov 2026):** Container `hermes-agent-service` on VPS dcloud pushed to `github.com/adilabkomgs/hermes_skill_docker.git` by mounting host SSH key (`github_ed25519`) into `/root/.ssh/`, writing `~/.ssh/config` with `IdentityFile`, and setting remote to SSH URL.
- **SSH key mount sequence:** `docker cp ~/.ssh/github_ed25519 <container>:/root/.ssh/`, `chmod 600`, then write `~/.ssh/config` with `StrictHostKeyChecking no`. Test with `ssh -T git@github.com`.
- **Security note:** `~/.ssh/config` redirect may trigger dotfile-overwrite security scan; approve it. Avoid echoing PATs in tooling; prefer SSH key mount or have user push manually.

### HTML/Web Data Extraction
- Avoid long shell pipelines with regex/quoting for web scraping; they often hit shell-escaping and scanner blocks.
- Safer pattern: `curl -sL -o /tmp/page.html <url>` then parse with Python in `execute_code` using `pathlib.Path.read_text()` and simple regex.
- For Wikipedia-style pages, the infobox template often contains structured data in JSON-like attributes; extract those with Python instead of fragile `grep`.
- Kitco gold price: scrape from page HTML, search for `Current Price:` and `data-testid="hp-change"` and `data-testid="hp-quote-time"`. USD/IDR from exchangerate-api.com. Convert oz→gram by /28.3495.

### Package Install Inside Running Container
- `docker exec <container> apt-get install ...` can fail with `dpkg lock-frontend` even as root if the container's filesystem is read-only or dpkg state is restricted.
- Do not assume container packages are mutable; if install fails, fallback to rebuilding the image with the needed tool baked in.
- Detect OS first: `docker exec <container> cat /etc/os-release` (Debian→apt, Alpine→apk).

### Web App Login Forms
- Some PHP login forms show "Password baru dan konfirmasi tidak sama." when POST fields don't match expected schema; inspect actual `<form>` inputs with `curl ... | grep -A 20 '<form'` before assuming username/password.
- Always check HTTP status (302 redirect = auth required) and title page to confirm login flow.

### GitHub Repo Status Check
- Use GitHub API: `curl -s https://api.github.com/repos/<user>/<repo> | python3 -m json.tool` to verify existence, branches, push time, visibility.
- 200 = exists; 404 = not found yet.
- Disk usage >= 80%: warn user and offer cleanup of old backups/logs.
- Load average near 0 with available RAM > 500MB: system is healthy.

## References
- `references/remote-check-errors.md` - Common error messages and troubleshooting guide
- `references/ssh-commands.md` - Ready-to-use SSH command templates (when added)
- `references/docker-backup-check.md` - Docker backup verification guide
- `references/git-inside-container.md` - Git setup, push auth issues, dpkg lock, non-interactive execution inside containers
- `references/dockertools-menu-usage.md` - Docker tools menu notes
- `references/github-pat-workflow.md` - Container-to-GitHub push flow using HTTPS + PAT and credential store

## Templates
- `templates/ssh-check.sh` - Automated script for remote directory verification via SSH

## Support Scripts
Use `skill_manage(action='write_file', file_path='scripts/<name>.sh')` to add verification scripts